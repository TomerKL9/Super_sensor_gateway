#include "RTG.h"

/*
 *	This example will show how to transmit and receive
 *	packets using the LWIP. The following code will
 *	program the EVB to be an echo server.
 *
 *	EVB configuration:
 *	IP: 		192.168.7.2
 *	NETMASK: 	255.255.255.0 (or 192.168.7.0/24)
 *	GATEWAY: 	192.168.7.1 (not in use but required by IDE)
 *	Port:		50,007
 GPIO Pin Assignments:
 * GPIOB Pin 8: Humidity sensor
 * GPIOA Pin 5: Saltiness sensor
 * GPIOE Pin 11: Light sensor
 * GPIOC Pin 8: PUMP
 */
#define sendingTimes 10
void send_binary_through_gpios(int i);
uint8_t callback_flag = 0;
uint8_t button_flag = 0;
ip_addr_t dest_ipaddr = {0};
u16_t dest_port = 0;
struct udp_pcb *upcb;
uint8_t incomming_buffer[MAX_BUF_LEN] = {0};
char message[MAX_BUF_LEN] = {0};
u16_t incomming_len = 0;
uint32_t lastDebounceTime = 0;  // Time of the last debounce
uint32_t pumpTime = 0;  // Time of the last debounce
const uint32_t debounceDelay = 600;  // Debounce delay in milliseconds
const uint32_t bitDelay = 50;  // Debounce delay in milliseconds
int led_id = 1;

uint32_t random_number;
uint8_t humidity[sendingTimes];
uint8_t saltiness[sendingTimes];
uint8_t light[sendingTimes];
uint8_t pump;
int random_range = 9;
GPIO_PinState pinState;

void rtg_main() {
    printf("Start of program\r\n");
    udpServer_init(); // Initialize UDP server
    while (1) {
        ethernetif_input(&gnetif); // Receive bytes from network
        sys_check_timeouts(); // Check timeout expiration

        if (callback_flag == 1) {
            send_packet(upcb, incomming_buffer, incomming_len, &dest_ipaddr, dest_port);
            callback_flag = 0;

            if (strcmp((const char *)incomming_buffer, "request_data") == 0) {
                send_packet(upcb, humidity, sendingTimes * sizeof(uint8_t), &dest_ipaddr, dest_port);
                send_packet(upcb, saltiness, sendingTimes * sizeof(uint8_t), &dest_ipaddr, dest_port);
                send_packet(upcb, light, sendingTimes * sizeof(uint8_t), &dest_ipaddr, dest_port);
            } else if (strcmp((const char *)incomming_buffer, "3") == 0) {
                if (pinState == GPIO_PIN_SET) {
                    uint32_t end_tick = HAL_GetTick();
                    uint32_t elapsed_time = end_tick - pumpTime;
                    snprintf(message, sizeof(message), "pump ON time: %lu ms\r\n", elapsed_time);
                } else {
                    snprintf(message, sizeof(message), "pump is OFF\r\n");
                }
                size_t message_length = strlen(message);
                send_packet(upcb, (uint8_t *)message, message_length, &dest_ipaddr, dest_port);
            } else {
                EXTI->SWIER |= (1 << 13); // Trigger interrupt
            }
            memset(incomming_buffer, 0, sizeof(incomming_buffer));
        }

        if (button_flag == 1) {
            for (int i = 0; i < sendingTimes; i++) {
                printf("----------------------------\r\n");
                printf("----------------------------\r\n");
                send_binary_through_gpios(i);
                HAL_Delay(debounceDelay);
            }
            button_flag = 0; // Reset button_flag
        }
    }
}


void send_binary_through_gpios(int i) {
    if (HAL_RNG_GenerateRandomNumber(&hrng, &random_number) == HAL_OK) {
        humidity[i] = (random_number) % random_range + 1;
        printf("Humidity: %d ---- ", humidity[i]);
    }
    if (HAL_RNG_GenerateRandomNumber(&hrng, &random_number) == HAL_OK) {
        saltiness[i] = (random_number) % random_range + 1;
        printf("Saltiness: %d ---- ", saltiness[i]);
    }
    if (HAL_RNG_GenerateRandomNumber(&hrng, &random_number) == HAL_OK) {
        light[i] = (random_number) % random_range + 1;
        printf("Light: %d\r\n", light[i]);
    }

    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOE, GPIO_PIN_11, GPIO_PIN_RESET);

    for (int j = 0; j < 4; j++) {
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, (humidity[i] & (1 << j)) ? GPIO_PIN_SET : GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, (saltiness[i] & (1 << j)) ? GPIO_PIN_SET : GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOE, GPIO_PIN_11, (light[i] & (1 << j)) ? GPIO_PIN_SET : GPIO_PIN_RESET);
        HAL_Delay(bitDelay); // Delay for signal stability
    }

    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_SET);
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);
    HAL_GPIO_WritePin(GPIOE, GPIO_PIN_11, GPIO_PIN_SET);
}


void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
    if (GPIO_Pin == USER_Btn_Pin) {
        uint32_t currentTime = HAL_GetTick();
        if ((currentTime - lastDebounceTime) > debounceDelay) {
            button_flag = 1; // Toggle button pressed state
            lastDebounceTime = currentTime; // Update last debounce time
        }
    } else if (GPIO_Pin == PUMP_Pin) {
        pinState = HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_8);

        if (pinState == GPIO_PIN_SET) {
            pumpTime = HAL_GetTick();
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_SET);
            printf("pump ON\r\n");
        } else {
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET);
            uint32_t end_tick = HAL_GetTick();
            uint32_t elapsed_time = end_tick - pumpTime;
            printf("pump is OFF after %lu ms\r\n", elapsed_time);
        }
    }
}

